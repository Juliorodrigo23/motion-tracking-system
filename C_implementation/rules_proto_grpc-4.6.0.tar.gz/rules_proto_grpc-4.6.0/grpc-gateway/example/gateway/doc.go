// Package gateway is an example of gRPC-Gateway server
package gateway
