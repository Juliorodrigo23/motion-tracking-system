JavaScript protobuf and gRPC dependencies managed by yarn.

To update a dependency:

- Update the `package.json` file with the new dependency version. Search https://www.npmjs.com/ for current versions.
- Ensure you have yarn installed locally: https://yarnpkg.com/en/docs/install
- Run `make yarn_upgrade` from the workspace root.
