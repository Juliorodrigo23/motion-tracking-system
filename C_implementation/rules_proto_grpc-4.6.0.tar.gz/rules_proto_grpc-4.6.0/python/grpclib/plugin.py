import grpclib.plugin.main

# Run grpclib plugin main
grpclib.plugin.main.main()
