# Attempt to import proto file
import demo_pb2
