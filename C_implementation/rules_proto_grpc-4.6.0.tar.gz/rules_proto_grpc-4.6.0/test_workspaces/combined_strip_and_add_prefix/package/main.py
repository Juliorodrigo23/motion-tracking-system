# Attempt to import proto file
import c.d.demo_pb2
