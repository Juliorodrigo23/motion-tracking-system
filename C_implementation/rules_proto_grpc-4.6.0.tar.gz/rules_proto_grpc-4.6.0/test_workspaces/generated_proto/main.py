# Attempt to import proto files, this should succeed
import generated_pb2
import generated_elsewhere_pb2
import static_pb2
