# Attempt to import proto file
import a.b.demo_pb2
